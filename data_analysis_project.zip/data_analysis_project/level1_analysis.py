import pandas as pd


df = pd.read_csv("restaurants.csv")  


print("First 5 rows:")
print(df.head())
print("\nColumns in dataset:")
print(df.columns)


top_cuisines = df['Cuisines'].value_counts().head(3)
total = len(df)
percentages = (top_cuisines / total) * 100
result1 = pd.DataFrame({
    'Cuisine': top_cuisines.index,
    'Count': top_cuisines.values,
    'Percentage': percentages.values.round(2)
})
print("\nTop 3 Cuisines:")
print(result1)


top_city = df['City'].value_counts().idxmax()
print("\nCity with the most restaurants:", top_city)

avg_ratings = df.groupby('City')['Aggregate rating'].mean()
best_rated_city = avg_ratings.idxmax()
best_rating = avg_ratings.max()

print("\nCity with highest average rating:", best_rated_city)
print("Average rating:", round(best_rating, 2))

print("\nTop 5 cities by average rating:")
print(avg_ratings.sort_values(ascending=False).head(5))
import matplotlib.pyplot as plt


price_counts = df['Price range'].value_counts().sort_index()
total = len(df)
price_percentages = (price_counts / total) * 100

print("\nPrice Range Distribution:")
for price, pct in price_percentages.items():
    print(f"Price Range {price}: {pct:.2f}% of restaurants")


plt.figure(figsize=(6, 4))
price_counts.plot(kind='bar', color='skyblue', edgecolor='black')
plt.title("Distribution of Price Ranges")
plt.xlabel("Price Range (1=Low, 4=High)")
plt.ylabel("Number of Restaurants")
plt.xticks(rotation=0)
plt.tight_layout()
plt.show()



print("\nUnique values in 'Has Online delivery':")
print(df['Has Online delivery'].unique())


online_delivery_counts = df['Has Online delivery'].value_counts()

yes_count = online_delivery_counts.loc['Yes'] if 'Yes' in online_delivery_counts else 0
no_count = online_delivery_counts.loc['No'] if 'No' in online_delivery_counts else 0
total_restaurants = yes_count + no_count

yes_percentage = (yes_count / total_restaurants) * 100
no_percentage = (no_count / total_restaurants) * 100

print(f"\nOnline Delivery:")
print(f"Yes: {yes_percentage:.2f}%")
print(f"No: {no_percentage:.2f}%")


avg_rating_with_delivery = df[df['Has Online delivery'] == 'Yes']['Aggregate rating'].dropna().mean()
avg_rating_without_delivery = df[df['Has Online delivery'] == 'No']['Aggregate rating'].dropna().mean()

print("\nAverage Ratings:")
print(f"With Online Delivery: {avg_rating_with_delivery:.2f}")
print(f"Without Online Delivery: {avg_rating_without_delivery:.2f}")
