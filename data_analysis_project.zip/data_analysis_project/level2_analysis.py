import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns


df = pd.read_csv("restaurants.csv", encoding="latin-1")


print("\n--- Task 1: Restaurant Ratings ---")

rating_counts = df['Aggregate rating'].value_counts().sort_index()
print("\nRating Distribution:")
print(rating_counts)


most_common_rating = rating_counts.idxmax()
print(f"\nMost Common Aggregate Rating: {most_common_rating}")


average_votes = df['Votes'].mean()
print(f"\nAverage number of votes received by restaurants: {average_votes:.2f}")


plt.figure(figsize=(8, 5))
plt.bar(rating_counts.index.astype(str), rating_counts.values, color='skyblue')
plt.xlabel('Aggregate Rating')
plt.ylabel('Number of Restaurants')
plt.title('Distribution of Restaurant Ratings')
plt.grid(True, linestyle='--', alpha=0.6)
plt.tight_layout()
plt.show()



print("\n--- Task 2: Cuisine Combinations ---")

df['Cuisines'] = df['Cuisines'].fillna("Unknown")
cuisine_counts = df['Cuisines'].value_counts().head(10)
print("\nTop 10 Cuisine Combinations:")
print(cuisine_counts)


top_cuisines = cuisine_counts.index.tolist()
rating_by_cuisine = df[df['Cuisines'].isin(top_cuisines)].groupby('Cuisines')['Aggregate rating'].mean().sort_values(ascending=False)
print("\nAverage Rating by Top Cuisine Combinations:")
print(rating_by_cuisine)


plt.figure(figsize=(10, 5))
sns.barplot(x=rating_by_cuisine.values, y=rating_by_cuisine.index, palette='viridis')
plt.xlabel('Average Rating')
plt.title('Average Rating by Top Cuisine Combinations')
plt.tight_layout()
plt.show()


print("\n--- Task 3: Geographic Analysis ---")

geo_df = df[['Longitude', 'Latitude', 'City']].dropna()


plt.figure(figsize=(10, 6))
sns.scatterplot(data=geo_df, x='Longitude', y='Latitude', hue='City', palette='Set2', legend=False, alpha=0.6)
plt.title("Restaurant Locations by City")
plt.xlabel("Longitude")
plt.ylabel("Latitude")
plt.grid(True, linestyle='--', alpha=0.5)
plt.tight_layout()
plt.show()


print("\n--- Task 4: Restaurant Chains ---")

chain_counts = df['Restaurant Name'].value_counts()
chains = chain_counts[chain_counts > 1]
print("\nTop Restaurant Chains (More than 1 outlet):")
print(chains.head(10))

top_chains = chains.head(10).index.tolist()
chain_rating = df[df['Restaurant Name'].isin(top_chains)].groupby('Restaurant Name')['Aggregate rating'].mean().sort_values(ascending=False)
print("\nAverage Ratings of Top Chains:")
print(chain_rating)


plt.figure(figsize=(10, 5))
sns.barplot(x=chain_rating.values, y=chain_rating.index, palette='coolwarm')
plt.xlabel('Average Rating')
plt.title('Top Restaurant Chains by Average Rating')
plt.tight_layout()
plt.show()
